var app = angular.module('app',  ['ngAnimate',
  'app.controllers',
  'app.questions_controller',
  'app.directives', 
  'ui.bootstrap'
  ]);